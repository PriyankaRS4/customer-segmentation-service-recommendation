"""Reusable customer segmentation and service recommendation pipeline."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "customer_data.csv"
OUTPUT = ROOT / "outputs"
OUTPUT.mkdir(exist_ok=True)
NUMERIC = ["tenure_months", "monthly_visits", "monthly_spend", "service_inquiries", "engagement_score", "days_since_last_interaction"]
CATEGORICAL = ["interest_area", "current_service", "preferred_channel"]


def load_and_clean(path=DATA_PATH):
    df = pd.read_csv(path)
    df = df.drop_duplicates(subset="customer_id").copy()
    # Enforce non-negative values where negative values would not be meaningful.
    for col in ["tenure_months", "monthly_visits", "monthly_spend", "service_inquiries", "days_since_last_interaction"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").clip(lower=0)
    df["engagement_score"] = pd.to_numeric(df["engagement_score"], errors="coerce").clip(0, 100)
    return df


def build_features(df):
    numeric_pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    categorical_pipe = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))])
    preprocessor = ColumnTransformer([("numeric", numeric_pipe, NUMERIC), ("categorical", categorical_pipe, CATEGORICAL)])
    matrix = preprocessor.fit_transform(df[NUMERIC + CATEGORICAL])
    return matrix, preprocessor


def segment_names(profile):
    """Assign understandable names to clusters based on observed behavior."""
    names = {}
    for cluster, row in profile.iterrows():
        if row["engagement_score"] >= profile["engagement_score"].quantile(.70) and row["monthly_spend"] >= profile["monthly_spend"].median():
            name = "Highly Engaged Customers"
        elif row["service_inquiries"] >= profile["service_inquiries"].quantile(.70):
            name = "Service-Focused Customers"
        elif row["tenure_months"] <= profile["tenure_months"].quantile(.30):
            name = "New Customers"
        else:
            name = "Occasional Customers"
        names[cluster] = name
    # Ensure labels are unique when cluster profiles overlap.
    seen = {}
    for k, v in names.items():
        seen[v] = seen.get(v, 0) + 1
        if seen[v] > 1:
            names[k] = f"{v} ({seen[v]})"
    return names


def recommend(row):
    """Transparent rule-based recommendations; no personal or sensitive attributes used."""
    recs = []
    if row["tenure_months"] < 6:
        recs.append("New-customer onboarding and setup guide")
    if row["engagement_score"] >= 75 and row["monthly_spend"] >= 12000:
        recs.append("Premium service bundle and loyalty benefits")
    elif row["days_since_last_interaction"] >= 30:
        recs.append("Re-engagement campaign with relevant learning resources")
    if row["service_inquiries"] >= 5:
        recs.append("Proactive support check-in and self-service FAQ")
    interest_map = {"Technology": "Technology and cloud-services learning path", "Learning": "Personalized learning plan", "Business": "Business productivity services"}
    if pd.notna(row.get("interest_area")):
        recs.append(interest_map.get(row["interest_area"], "Explore services matched to your interests"))
    if not recs:
        recs.append("Monthly product tips and a personalized service overview")
    return "; ".join(dict.fromkeys(recs))


def run_pipeline(path=DATA_PATH, k=4):
    df = load_and_clean(path)
    matrix, preprocessor = build_features(df)
    model = KMeans(n_clusters=k, random_state=42, n_init=20)
    labels = model.fit_predict(matrix)
    df["cluster_id"] = labels
    profile = df.groupby("cluster_id")[NUMERIC].mean().round(2)
    names = segment_names(profile)
    df["segment"] = df["cluster_id"].map(names)
    df["recommendations"] = df.apply(recommend, axis=1)
    # PCA is for 2D visualization only, not for model training.
    coords = PCA(n_components=2, random_state=42).fit_transform(matrix)
    df["pca_1"], df["pca_2"] = coords[:, 0], coords[:, 1]
    metrics = {"silhouette_score": float(silhouette_score(matrix, labels)),
               "davies_bouldin_score": float(davies_bouldin_score(matrix, labels)),
               "calinski_harabasz_score": float(calinski_harabasz_score(matrix, labels)),
               "n_customers": int(len(df)), "n_clusters": int(k)}
    df.to_csv(OUTPUT / "segmented_customers.csv", index=False)
    profile_out = df.groupby("segment").agg(customer_count=("customer_id", "count"), avg_spend=("monthly_spend", "mean"), avg_engagement=("engagement_score", "mean"), avg_visits=("monthly_visits", "mean"), avg_inquiries=("service_inquiries", "mean")).round(2).reset_index()
    profile_out.to_csv(OUTPUT / "segment_profiles.csv", index=False)
    (OUTPUT / "evaluation_metrics.json").write_text(json.dumps(metrics, indent=2))
    (OUTPUT / "business_recommendations.md").write_text(make_business_recommendations(profile_out))
    return df, profile_out, metrics


def make_business_recommendations(profiles):
    lines = ["# Business Recommendations", "", "Recommendations below are generated from aggregate segment behavior. Validate with real business outcomes before deployment.", ""]
    for _, r in profiles.iterrows():
        name = r["segment"]
        if "Highly Engaged" in name:
            action = "Reward loyalty, offer relevant premium bundles, and invite feedback without over-messaging."
        elif "Service-Focused" in name:
            action = "Offer proactive support, improve FAQ/self-service content, and investigate recurring inquiry themes."
        elif "New Customers" in name:
            action = "Provide a clear onboarding journey, setup tips, and early check-ins to build confidence."
        else:
            action = "Use useful educational content and targeted reminders to encourage repeat engagement."
        lines += [f"## {name}", f"- Customers: {int(r['customer_count'])}", f"- Average monthly spend: {r['avg_spend']:.2f}", f"- Average engagement score: {r['avg_engagement']:.1f}", f"- Action: {action}", ""]
    return "\n".join(lines)

if __name__ == "__main__":
    data, profiles, metrics = run_pipeline()
    print("Pipeline complete. Metrics:", json.dumps(metrics, indent=2))
    print(profiles.to_string(index=False))
