# Customer Segmentation & Service Recommendation System

A complete portfolio project that groups customers by behavior, interests, engagement, service inquiries, spending, and interaction patterns, then recommends relevant services using transparent rules.

## Features
- Synthetic customer dataset with 900 records
- Data cleaning and preprocessing (missing-value imputation, scaling, one-hot encoding)
- K-Means clustering with configurable K
- Cluster evaluation: silhouette, Davies–Bouldin, and Calinski–Harabasz scores
- PCA-based 2D cluster visualization
- Segment profiles and business recommendations
- Rule-based service recommendations for each customer
- Streamlit dashboard with filtering and CSV downloads

## Project structure
```text
customer_segmentation_service_recommendation/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── customer_data.csv
├── src/
│   └── pipeline.py
├── outputs/
│   ├── segmented_customers.csv
│   ├── segment_profiles.csv
│   ├── evaluation_metrics.json
│   └── business_recommendations.md
└── reports/
    └── project_report.md
```

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/pipeline.py
streamlit run app.py
```

Open the local URL printed by Streamlit. Use the sidebar to choose the number of clusters and click **Run / Refresh segmentation**.

## Dataset dictionary
| Column | Meaning |
|---|---|
| `customer_id` | Synthetic unique customer identifier |
| `tenure_months` | Months since becoming a customer |
| `monthly_visits` | Approximate visits/interactions in a month |
| `monthly_spend` | Approximate monthly spend in arbitrary currency units |
| `service_inquiries` | Number of service-related inquiries |
| `engagement_score` | Synthetic engagement score from 0 to 100 |
| `days_since_last_interaction` | Recency of the last interaction |
| `interest_area` | Broad service interest: Technology, Learning, or Business |
| `current_service` | Current service category |
| `preferred_channel` | Preferred communication channel |

All data is synthetic and does not describe real individuals. Spending values are illustrative rather than a claim about a specific currency or business.

## Method choices
K-Means is a practical baseline for numeric feature vectors and makes cluster centers easy to inspect. Numeric columns are standardized so high-magnitude spending values do not dominate the distance calculation. Categorical columns are one-hot encoded. PCA is used only to visualize the high-dimensional feature vectors in two dimensions.

The default `K=4` is a starting point, not a claim that four is universally optimal. Compare evaluation metrics, segment profiles, stability, and business usefulness before selecting a production value.

## Recommendation logic
Recommendations use interpretable rules based on tenure, engagement, spending, interaction recency, inquiry volume, and stated interest. They are suggestions for a demo and should be evaluated with customer feedback and business outcomes before production.

## Deliverables
- Dataset and preprocessing pipeline
- K-Means clustering and evaluation metrics
- Customer segment profiles
- PCA visualization through dashboard
- Per-customer service recommendation logic
- Business recommendation report
- Interactive Streamlit dashboard

## GitHub and LinkedIn submission
1. Create a public GitHub repository and upload the project files.
2. Add screenshots of the dashboard to the repository if available.
3. Include this README and a short summary of the dataset, methods, and limitations.
4. Publish a LinkedIn post describing the problem, tools, outcomes, and GitHub repository URL.

## Disclaimer
This is an educational portfolio project. Do not upload customer-identifying or confidential data to a public repository. For real deployments, follow applicable privacy, security, and consent requirements.
