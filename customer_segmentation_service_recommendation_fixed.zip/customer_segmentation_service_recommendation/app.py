from pathlib import Path
import json
import sys
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from pipeline import run_pipeline

st.set_page_config(page_title="Customer Segmentation & Service Recommendations", page_icon="👥", layout="wide")
st.title("👥 Customer Segmentation & Service Recommendation System")
st.caption("Explore customer behavior clusters and transparent, rule-based service recommendations.")

with st.sidebar:
    st.header("Configuration")
    k = st.slider("Number of clusters (K)", min_value=2, max_value=8, value=4)
    st.info("This demo uses a synthetic customer dataset. Replace it with appropriately consented, de-identified data for real use.")

if st.button("Run / Refresh segmentation", type="primary") or not (ROOT / "outputs/segmented_customers.csv").exists():
    with st.spinner("Cleaning data, creating features, and clustering customers..."):
        data, profiles, metrics = run_pipeline(k=k)
else:
    data = pd.read_csv(ROOT / "outputs/segmented_customers.csv")
    profiles = pd.read_csv(ROOT / "outputs/segment_profiles.csv")
    metrics = json.loads((ROOT / "outputs/evaluation_metrics.json").read_text())
    # If selected K differs from saved model output, rerun to respect the control.
    if metrics.get("n_clusters") != k:
        data, profiles, metrics = run_pipeline(k=k)

m1, m2, m3, m4 = st.columns(4)
m1.metric("Customers", f"{metrics['n_customers']:,}")
m2.metric("Segments", metrics["n_clusters"])
m3.metric("Silhouette score", f"{metrics['silhouette_score']:.3f}")
m4.metric("Davies–Bouldin score", f"{metrics['davies_bouldin_score']:.3f}")
st.caption("Silhouette is better when higher; Davies–Bouldin is better when lower. Use these metrics alongside business interpretation.")

tab1, tab2, tab3, tab4 = st.tabs(["Segment Overview", "Customer Explorer", "Recommendations", "Methodology"])
with tab1:
    left, right = st.columns(2)
    with left:
        st.subheader("Customers by segment")
        counts = data["segment"].value_counts().rename_axis("segment").reset_index(name="customers")
        st.bar_chart(counts.set_index("segment"))
    with right:
        st.subheader("2D PCA cluster view")
        fig, ax = plt.subplots(figsize=(7, 4))
        sns.scatterplot(data=data, x="pca_1", y="pca_2", hue="segment", alpha=.75, s=35, ax=ax)
        ax.set_title("PCA projection (visualization only)")
        st.pyplot(fig, clear_figure=True)
    st.subheader("Segment profiles")
    st.dataframe(profiles, use_container_width=True, hide_index=True)
    st.download_button("Download segment profiles CSV", profiles.to_csv(index=False).encode(), "segment_profiles.csv", "text/csv")
with tab2:
    segments = ["All"] + sorted(data["segment"].dropna().unique().tolist())
    selected = st.selectbox("Filter by segment", segments)
    search = st.text_input("Search customer ID")
    view = data.copy()
    if selected != "All": view = view[view["segment"] == selected]
    if search.strip(): view = view[view["customer_id"].str.contains(search.strip(), case=False, na=False)]
    st.dataframe(view[["customer_id", "segment", "tenure_months", "monthly_visits", "monthly_spend", "service_inquiries", "engagement_score", "interest_area", "current_service"]], use_container_width=True, hide_index=True)
    st.download_button("Download filtered customers CSV", view.to_csv(index=False).encode(), "filtered_customers.csv", "text/csv")
with tab3:
    st.subheader("Suggested services")
    chosen = st.selectbox("Choose a customer", data["customer_id"].tolist())
    customer = data.loc[data["customer_id"] == chosen].iloc[0]
    st.write(f"**Segment:** {customer['segment']}")
    st.write(f"**Current service:** {customer['current_service']}")
    st.write("**Recommendations:**")
    for rec in str(customer["recommendations"]).split("; "):
        st.markdown(f"- {rec}")
    st.caption("Recommendations are transparent rules for demonstration, not a guarantee of suitability or business results.")
    st.subheader("Business actions by segment")
    rec_path = ROOT / "outputs/business_recommendations.md"
    if rec_path.exists(): st.markdown(rec_path.read_text())
with tab4:
    st.markdown("""
### Workflow
1. Load synthetic customer data and remove duplicate customer IDs.
2. Impute missing numeric values with the median and categorical values with the most frequent category.
3. Standardize numeric features and one-hot encode categorical features.
4. Apply K-Means clustering. The default K is 4 and can be adjusted in the sidebar.
5. Evaluate clusters using silhouette, Davies–Bouldin, and Calinski–Harabasz scores.
6. Use PCA to create a 2D visualization; PCA coordinates are not used to fit K-Means.
7. Create human-readable segment labels and transparent rule-based service recommendations.

### Limitations
- Data is synthetic and is intended for portfolio/demo use.
- Cluster labels are heuristics; inspect profiles and validate with domain experts.
- Recommendation rules should be tested for usefulness, fairness, privacy, and measurable outcomes before production.
""")
